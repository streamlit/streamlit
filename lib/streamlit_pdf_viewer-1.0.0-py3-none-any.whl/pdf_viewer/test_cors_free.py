import streamlit as st
from pdf_viewer import pdf_viewer

st.set_page_config(page_title="PDF Viewer Test", layout="centered")

st.title("📄 PDF Viewer Component Test")

# Use a PDF URL that allows CORS
test_pdf_url = "https://raw.githubusercontent.com/mozilla/pdf.js/ba2edeae/web/compressed.tracemonkey-pldi-09.pdf"

st.write("Testing with a CORS-friendly PDF URL...")

# Display the PDF viewer component
result = pdf_viewer(
    file=test_pdf_url,
    width=700,
    height=600,
    key="pdf_test"
)

# Show component state
if result:
    st.success("✅ Component is working!")
    st.json(result)
else:
    st.info("Waiting for component to load...")

# Alternative: Test with uploaded file
st.markdown("---")
st.subheader("Or upload your own PDF")
uploaded_file = st.file_uploader("Choose a PDF file", type="pdf")

if uploaded_file is not None:
    pdf_data = uploaded_file.read()
    
    result2 = pdf_viewer(
        file=pdf_data,
        width=1900,
        height=1000,
    )
    
    if result2:
        st.json(result2) 