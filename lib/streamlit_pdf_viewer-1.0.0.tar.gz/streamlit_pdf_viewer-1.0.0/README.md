# streamlit-pdf

A lightweight **Streamlit** feature that seamlessly displays **PDF** files in your apps, allowing for simple, responsive, and clean document viewing with minimal effort.

## Filing Issues

Please file [bug reports](https://github.com/streamlit/streamlit/issues/new?template=bug_report.yml) and [enhancement requests](https://github.com/streamlit/streamlit/issues/new?template=feature_request.yml) through our main Streamlit repo.

## 🚀 Features

- **Multiple PDF Sources**: Support for URLs, local files, uploaded files, and raw bytes
- **Responsive Design**: Adapts to different screen sizes with flexible width/height options
- **Clean Interface**: Simple, distraction-free PDF viewing
- **Built-in Integration**: Native Streamlit component with seamless integration

---

## 📦 Installation

```bash
pip install streamlit[pdf]
```

Ensure you have **Streamlit** installed:


---

## 💡 Usage

Here's how to display a PDF file in your Streamlit app:

```python
import streamlit as st

# Display PDF from URL
st.pdf("https://example.com/document.pdf")

# Display with custom dimensions
st.pdf("path/to/document.pdf", width=800, height=600)

# Display uploaded file
uploaded_file = st.file_uploader("Choose a PDF file", type="pdf")
if uploaded_file is not None:
    st.pdf(uploaded_file)
```

---

## ⚙️ API Reference

### `st.pdf(data, width="stretch", height="stretch")`

#### Parameters:

- **`data`** (_str | Path | bytes | BytesIO_): The PDF file to show. This can be one of the following:
  - A URL (string) for a hosted PDF file (`"https://example.com/doc.pdf"`)
  - A path to a local PDF file (`"./documents/sample.pdf"`)
  - A file-like object, e.g. a file opened with `open` or an `UploadedFile` returned by `st.file_uploader`
  - Raw bytes data

- **`width`** (_int | "stretch"_, optional): Desired width of the PDF viewer. Can be "stretch" for full width or an integer for pixel width. Default: "stretch"

- **`height`** (_int | "stretch"_, optional): Height of the PDF viewer. Can be "stretch" for full height or an integer for pixel height. Default: "stretch"

---

## 🖼️ Examples

### Basic PDF Display
```python
import streamlit as st

st.title("PDF Viewer Example")

# Display a PDF from URL
st.pdf("https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf")
```

### File Upload with PDF Display
```python
import streamlit as st

st.title("Upload and View PDF")

uploaded_file = st.file_uploader("Choose a PDF file", type="pdf")
if uploaded_file is not None:
    st.pdf(uploaded_file, width="stretch")
```

### Custom Dimensions
```python
import streamlit as st

# Display PDF with specific dimensions
st.pdf("document.pdf", width=1000, height=800)

# Display PDF with full width
st.pdf("document.pdf", width="stretch", height=600)
```

### Reading from Local File
```python
import streamlit as st

with open("document.pdf", "rb") as file:
    st.pdf(file.read(), width=700)
```

---

## 📝 Contributing

Feel free to file issues in [our Streamlit Repository](https://github.com/streamlit/streamlit/issues/new/choose).

Contributions are welcome 🚀, however, please inform us before building a feature.

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).

---

## 🙋 FAQ

**Q:** What PDF sources are supported?

- **A:** URLs, local file paths, uploaded files via `st.file_uploader`, and raw bytes data.

**Q:** Can I control the PDF viewer size?

- **A:** Yes! Use `width` and `height` parameters with either pixel values (integers) or `"stretch"` for responsive sizing.

**Q:** Does it work with file uploads?

- **A:** Absolutely! Pass the uploaded file object directly to `st.pdf()` without needing to call `.read()`.

**Q:** Can I display multiple PDFs on the same page?

- **A:** Yes! Just call `st.pdf()` multiple times with different PDF sources.

---

Happy Streamlit-ing! 🎉