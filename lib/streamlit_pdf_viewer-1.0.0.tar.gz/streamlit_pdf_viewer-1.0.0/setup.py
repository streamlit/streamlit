from pathlib import Path

import setuptools

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setuptools.setup(
    name="streamlit-pdf-viewer",
    version="1.0.0",
    author="Siddhant Mohile",
    author_email="siddhant.mohile@snowflake.com",
    description="A Streamlit component for viewing PDF files with react-pdf",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/streamlit/streamlit-pdf-viewer",
    packages=setuptools.find_packages(),
    include_package_data=True,
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Framework :: Streamlit",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Office/Business :: Office Suites",
        "Topic :: Multimedia :: Graphics :: Viewers",
    ],
    python_requires=">=3.9",
    install_requires=[
        "streamlit >= 1.28.0",
        "requests >= 2.25.0",
    ],
    extras_require={
        "devel": [
            "wheel",
            "pytest==7.4.0",
            "playwright==1.48.0",
            "requests==2.31.0",
            "pytest-playwright-snapshot==1.0",
            "pytest-rerunfailures==12.0",
        ]
    },
    keywords="streamlit pdf viewer react component",
)
