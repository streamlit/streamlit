# Copyright (c) Snowflake Inc. (2025)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import streamlit.components.v1 as components
import base64
from typing import Union, Optional, Dict, Any


_RELEASE = True

# Declare a Streamlit component for PDF viewing
if not _RELEASE:
    _component_func = components.declare_component(
        "pdf_viewer",
        url="http://localhost:3001",
    )
else:
    # When we're distributing a production version of the component, we'll
    # replace the `url` param with `path`, and point it to the component's
    # build directory:
    parent_dir = os.path.dirname(os.path.abspath(__file__))
    build_dir = os.path.join(parent_dir, "frontend/build")

    _component_func = components.declare_component("pdf_viewer", path=build_dir)


def pdf_viewer(
    file: Union[str, bytes],
    height: int = 600,
    key: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Create a new instance of the PDF viewer component.

    This component allows you to display PDF files in your Streamlit app with
    a clean, minimal design. The viewer uses smart lazy loading to improve 
    performance with large PDF files - pages are loaded only when they become 
    visible in the viewport.

    Parameters
    ----------
    file : str or bytes
        The PDF file to display. This can be:
        - A URL to a PDF file (e.g., "https://example.com/document.pdf")
        - A local file path (e.g., "./documents/sample.pdf")
        - Raw bytes of a PDF file
        - Base64 encoded PDF data
    height : int, optional
        The height of the PDF viewer in pixels. Default is 600.
    key : str or None, optional
        An optional key that uniquely identifies this component. If this is
        None, and the component's arguments are changed, the component will
        be re-mounted in the Streamlit frontend and lose its current state.

    Returns
    -------
    dict or None
        A dictionary containing information about user interactions with the PDF viewer:
        - 'event': Type of event ('document_loaded', 'page_changed', 'document_error')
        - 'numPages': Total number of pages in the PDF (for 'document_loaded' and 'page_changed')
        - 'currentPage': Current page number (for 'document_loaded' and 'page_changed')
        - 'error': Error message (for 'document_error')

        Returns None if no interaction has occurred yet.

    Notes
    -----
    Performance Optimization:
    - Uses Intersection Observer API for intelligent lazy loading
    - Only loads pages that are actually visible in the viewport
    - Handles jumping to any page (e.g., page 100) efficiently
    - Pre-loads pages 200px before they become visible for smooth scrolling
    - First 5 pages load immediately for instant interaction
    - Minimal memory usage as only visible pages are rendered

    Examples
    --------
    Basic usage with a URL:
    >>> pdf_viewer("https://example.com/document.pdf")

    With custom height:
    >>> pdf_viewer(
    ...     file="./documents/report.pdf",
    ...     height=1000
    ... )

    Loading from bytes:
    >>> with open("document.pdf", "rb") as f:
    ...     pdf_bytes = f.read()
    >>> pdf_viewer(pdf_bytes)
    """

    # Process the file parameter
    processed_file = _process_file_input(file)

    # Call the component function with processed arguments
    component_value = _component_func(
        file=processed_file, height=height, key=key, default=None
    )

    return component_value


def _process_file_input(file: Union[str, bytes]) -> str:
    """Process different types of file inputs into a format the frontend can handle.

    Parameters
    ----------
    file : str or bytes
        The input file in various formats

    Returns
    -------
    str
        A URL or data URI that the frontend can use to load the PDF
    """
    if isinstance(file, bytes):
        # Convert bytes to base64 data URI
        b64_data = base64.b64encode(file).decode("utf-8")
        return f"data:application/pdf;base64,{b64_data}"

    elif isinstance(file, str):
        if file.startswith(("http://", "https://")):
            # It's already a URL
            return file
        elif file.startswith("data:"):
            # It's already a data URI
            return file
        else:
            # Assume it's a local file path, convert to base64 data URI
            try:
                with open(file, "rb") as f:
                    pdf_bytes = f.read()
                b64_data = base64.b64encode(pdf_bytes).decode("utf-8")
                return f"data:application/pdf;base64,{b64_data}"
            except FileNotFoundError:
                raise FileNotFoundError(f"PDF file not found: {file}")
            except Exception as e:
                raise Exception(f"Error reading PDF file {file}: {str(e)}")

    else:
        raise TypeError(f"Unsupported file type: {type(file)}. Expected str or bytes.")
